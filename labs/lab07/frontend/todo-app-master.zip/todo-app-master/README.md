# TODO web application

A simple TODO web application developed to demonstrate how to create
web apps from the ground app.

## How to run a web server

For development purpose you can install the Node `http-server` package:

```
npm install -g http-server
```

And then run it like this:

```
http-server . # remind this final dot, it means serve content from here
```

It will be listining on port 8080.

